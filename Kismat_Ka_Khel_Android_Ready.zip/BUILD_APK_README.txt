Kismat Ka Khel Android-ready project
Application ID: com.kismat.khel
Version: 1.0

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. The debug APK will be under app/build/outputs/apk/debug/app-debug.apk.

This project wraps the included HTML app in a native Android WebView.
