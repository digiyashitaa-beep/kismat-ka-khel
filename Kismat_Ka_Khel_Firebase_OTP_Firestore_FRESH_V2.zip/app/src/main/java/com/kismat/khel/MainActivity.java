package com.kismat.khel;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView webView;
    private FirebaseFirestore db;
    private FirebaseAuth auth;
    private String verificationId;
    private String pendingAction;
    private String pendingProfileJson;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseApp.initializeApp(this);
        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        webView.addJavascriptInterface(new FirebaseBridge(), "AndroidFirebase");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    private class FirebaseBridge {
        @JavascriptInterface
        public void startPhoneAuth(String phone, String action, String profileJson) {
            String normalized = phone == null ? "" : phone.replaceAll("\\D", "");
            if (normalized.length() == 10) normalized = "91" + normalized;
            final String e164 = "+" + normalized;
            pendingAction = action;
            pendingProfileJson = profileJson;
            PhoneAuthOptions options = PhoneAuthOptions.newBuilder(auth)
                    .setPhoneNumber(e164)
                    .setTimeout(60L, java.util.concurrent.TimeUnit.SECONDS)
                    .setActivity(MainActivity.this)
                    .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                        @Override public void onVerificationCompleted(PhoneAuthCredential credential) {
                            signInWithCredential(credential, null);
                        }
                        @Override public void onVerificationFailed(com.google.firebase.FirebaseException e) {
                            sendToWeb("window.onOtpError(" + JSONObject.quote(e.getMessage() == null ? "OTP could not be sent." : e.getMessage()) + ")");
                        }
                        @Override public void onCodeSent(String id, PhoneAuthProvider.ForceResendingToken token) {
                            verificationId = id;
                            sendToWeb("window.onOtpSent(" + JSONObject.quote(action == null ? "" : action) + ")");
                        }
                    }).build();
            PhoneAuthProvider.verifyPhoneNumber(options);
        }

        @JavascriptInterface
        public void verifyOtp(String code) {
            if (verificationId == null) { sendToWeb("window.onOtpError('OTP session expired. Please request a new OTP.')"); return; }
            PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, code);
            signInWithCredential(credential, code);
        }

        private void signInWithCredential(PhoneAuthCredential credential, String ignored) {
            auth.signInWithCredential(credential).addOnSuccessListener(result -> {
                try {
                    JSONObject profile = new JSONObject(pendingProfileJson == null ? "{}" : pendingProfileJson);
                    String uid = result.getUser().getUid();
                    String phone = result.getUser().getPhoneNumber();
                    if (phone == null) phone = profile.optString("mobile");
                    String normalizedPhone = phone.replaceAll("\\D", "");
                    if (normalizedPhone.startsWith("91") && normalizedPhone.length() == 12) normalizedPhone = normalizedPhone.substring(2);
                    String email = profile.optString("email").toLowerCase();
                    boolean creator = email.equals("digiyashitaa@gmail.com") && normalizedPhone.equals("8595319100");
                    db.collection("users").document(uid).get().addOnSuccessListener(existing -> {
                        try {
                            if ("signup".equals(pendingAction) && existing.exists()) {
                                sendToWeb("window.onOtpError('An account already exists for this mobile number. Please Log In instead.')");
                                return;
                            }
                            if ("login".equals(pendingAction) && !creator) {
                                if (!existing.exists()) { sendToWeb("window.onOtpError('No account found for this mobile number. Please Sign Up first.')"); return; }
                                String en=existing.getString("email"); String nn=existing.getString("name");
                                if (en==null || nn==null || !en.equalsIgnoreCase(email) || !nn.equalsIgnoreCase(profile.optString("name"))) {
                                    sendToWeb("window.onOtpError('Name or email does not match this account.')"); return;
                                }
                            }
                            String joined = existing.exists() && existing.getString("joined") != null ? existing.getString("joined") : profile.optString("joined");
                            String role = creator ? "creator" : "reader";
                            Map<String, Object> data = new HashMap<>();
                            data.put("id", uid); data.put("uid", uid); data.put("name", profile.optString("name"));
                            data.put("email", email); data.put("mobile", "+91" + normalizedPhone);
                            data.put("joined", joined); data.put("role", role);
                            db.collection("users").document(uid).set(data)
                                .addOnSuccessListener(v -> sendToWeb("window.onOtpVerified(" + JSONObject.quote(pendingAction == null ? "" : pendingAction) + "," + JSONObject.quote(new JSONObject(data).toString()) + ")"))
                                .addOnFailureListener(e -> sendToWeb("window.onOtpError('Could not save account to Firebase: ' + " + JSONObject.quote(e.getMessage() == null ? "unknown error" : e.getMessage()) + ")"));
                        } catch (Exception e) { sendToWeb("window.onOtpError('Account data error.')"); }
                    }).addOnFailureListener(e -> sendToWeb("window.onOtpError('Could not check account in Firebase.')"));
                } catch (Exception e) { sendToWeb("window.onOtpError('Account data error.')"); }
            }).addOnFailureListener(e -> sendToWeb("window.onOtpError('Invalid OTP or sign-in failed.')"));
        }

        @JavascriptInterface
        public void saveReader(String json) {
            try {
                JSONObject o = new JSONObject(json);
                String uid = auth.getCurrentUser() != null ? auth.getCurrentUser().getUid() : o.optString("id", "u_" + System.currentTimeMillis());
                Map<String, Object> data = new HashMap<>();
                data.put("id", uid); data.put("uid", uid); data.put("name", o.optString("name"));
                data.put("email", o.optString("email").toLowerCase()); data.put("mobile", o.optString("mobile"));
                data.put("joined", o.optString("joined")); data.put("role", o.optString("role", "reader"));
                db.collection("users").document(uid).set(data);
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void loadReaders() {
            db.collection("users").whereEqualTo("role", "reader").get()
                .addOnSuccessListener(snapshot -> {
                    try {
                        JSONArray arr = new JSONArray();
                        for (QueryDocumentSnapshot doc : snapshot) {
                            JSONObject o = new JSONObject();
                            o.put("id", doc.getString("id")); o.put("name", doc.getString("name"));
                            o.put("email", doc.getString("email")); o.put("mobile", doc.getString("mobile"));
                            o.put("joined", doc.getString("joined")); o.put("role", doc.getString("role")); arr.put(o);
                        }
                        sendToWeb("window.onRemoteReaders(" + JSONObject.quote(arr.toString()) + ")");
                    } catch (Exception e) { sendToWeb("window.onRemoteReaders('[]')"); }
                }).addOnFailureListener(e -> sendToWeb("window.onRemoteReaders('[]')"));
        }
    }

    private void sendToWeb(String script) {
        runOnUiThread(() -> webView.evaluateJavascript(script, null));
    }
}
