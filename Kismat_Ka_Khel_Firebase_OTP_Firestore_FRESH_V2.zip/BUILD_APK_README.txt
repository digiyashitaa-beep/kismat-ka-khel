Kismat Ka Khel — Firebase OTP + Firestore Android project
Application ID: com.kismat.khel
Version: 1.2

Includes:
- Native Firebase Phone OTP (Android Phone Auth)
- Firestore reader profiles (name, email, mobile)
- Creator Studio reader sync across devices
- Existing WebView app UI, episodes, comments, likes and progress

Build with Android Studio or your existing GitHub Actions workflow.
Debug APK: app/build/outputs/apk/debug/app-debug.apk

Firebase setup:
1. Phone Authentication must be enabled in Firebase Console.
2. Firestore must be created.
3. Deploy firestore.rules from this project in Firestore Database -> Rules.
4. google-services.json is already included for com.kismat.khel.
